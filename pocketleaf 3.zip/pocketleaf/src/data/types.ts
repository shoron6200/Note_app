import type { NoteColor, NoteFont, NoteSize } from '../theme/constants';
import type { Repeat } from './time';

export type NoteType = 'text' | 'checklist';
export type Sort = 'updated' | 'created' | 'title';
export type ViewMode = 'grid' | 'list';
export type ThemeSetting = 'system' | 'light' | 'dark';

export type Item = { id: string; noteId: string; text: string; checked: boolean; position: number };

export type Reminder = {
  id: string;
  noteId: string;
  fireAt: number;
  timezone: string;
  localTime: string;
  repeat: Repeat;
  osNotificationId: string | null;
  status: 'scheduled' | 'fired' | 'done';
};

/** One card on the home grid, in search results, or in the trash. */
export type NoteSummary = {
  id: string;
  type: NoteType;
  title: string;
  preview: string;
  color: NoteColor;
  font: NoteFont;
  pinned: boolean;
  folderId: string | null;
  folderName: string | null;
  createdAt: number;
  updatedAt: number;
  deletedAt: number | null;
  items: { text: string; checked: boolean }[];
  itemCount: number;
  doneCount: number;
  reminder: Pick<Reminder, 'fireAt' | 'repeat' | 'status'> | null;
};

export type NoteFull = {
  id: string;
  type: NoteType;
  title: string;
  body: string;
  color: NoteColor;
  font: NoteFont;
  fontSize: NoteSize;
  pinned: boolean;
  folderId: string | null;
  createdAt: number;
  updatedAt: number;
  deletedAt: number | null;
  items: Item[];
  reminder: Reminder | null;
};

export type NotePatch = Partial<
  Pick<NoteFull, 'title' | 'body' | 'color' | 'font' | 'fontSize' | 'folderId' | 'pinned'>
>;

export type Folder = { id: string; name: string; position: number; count: number };

export type Settings = {
  viewMode: ViewMode;
  sort: Sort;
  theme: ThemeSetting;
  lastBackupAt: number | null;
  lastSnapshotAt: number | null;
};

/** What the OS notification layer must do. A no-op on web. */
export interface Scheduler {
  schedule(r: { noteId: string; title: string; body: string; fireAt: number }): Promise<string | null>;
  cancel(osId: string): Promise<void>;
  /** Everything currently scheduled by this app: OS id -> note id. */
  listScheduled(): Promise<{ osId: string; noteId: string | null }[]>;
  /** iOS keeps at most 64 pending local notifications per app. */
  maxPending: number;
}

export class DuplicateFolderError extends Error {
  constructor() {
    super('duplicate folder name');
    this.name = 'DuplicateFolderError';
  }
}

export class BackupFormatError extends Error {
  constructor(reason: string) {
    super(reason);
    this.name = 'BackupFormatError';
  }
}
